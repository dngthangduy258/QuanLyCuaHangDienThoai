﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;

namespace QuanLyCuaHangDienThoai.Models
{
    public class Product
    {
        public int ID { get; set; }
        public int SoLuong { get; set; }
        public decimal DonGia { get; set; }

    }
   
}